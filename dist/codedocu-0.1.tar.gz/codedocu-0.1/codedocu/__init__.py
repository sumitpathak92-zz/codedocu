# -*- coding: utf-8 -*-

def hello():
    return "Currently its in the initial phase"
